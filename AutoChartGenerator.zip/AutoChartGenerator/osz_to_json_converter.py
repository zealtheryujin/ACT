import zipfile
import os
import json
import re
import math
import random
from pathlib import Path
import shutil

INPUT_FOLDER = "input"
OUTPUT_FOLDER = "output"

DEFAULT_BASE_SPEED_4K = 2.0
DEFAULT_BASE_SPEED_6K = 3.0

OSU_MANIA_WIDTH = 512

MIN_NOTES_PER_COLOR = 2
MAX_NOTES_PER_COLOR = 7
COLOR_SWAP_CHANCE = 0.5

BLUE_NOTE_PERCENTAGE_4K = 0.08
BLUE_NOTE_PERCENTAGE_6K = 0.10


def find_osz_files(input_folder):
    input_path = Path(input_folder)
    osz_files = list(input_path.glob("*.osz"))
    zip_files = list(input_path.glob("*.zip"))
    return osz_files + zip_files


def extract_osz(osz_path, extract_to):
    extract_path = Path(extract_to) / osz_path.stem
    
    extract_path.mkdir(parents=True, exist_ok=True)
    
    print(f"📦 Unpacking {osz_path.name}...")
    with zipfile.ZipFile(osz_path, 'r') as zip_ref:
        zip_ref.extractall(extract_path)
    
    print(f"✅ Extracted to: {extract_path}")
    return extract_path


def find_and_rename_audio(extract_path):
    audio_extensions = ['.mp3', '.wav', '.ogg', '.m4a', '.flac']
    
    audio_file = None
    for ext in audio_extensions:
        found = list(extract_path.glob(f"*{ext}"))
        if found:
            audio_file = found[0]
            break
    
    if audio_file is None:
        print(f"⚠️  Audio file not found! ({', '.join(audio_extensions)})")
        return None
    
    new_name = f"audio{audio_file.suffix}"
    new_path = extract_path / new_name
    
    if audio_file.name == new_name:
        print(f"✅ Audio file already correctly named: {new_name}")
        return new_path
    
    audio_file.rename(new_path)
    print(f"✅ Audio file renamed: {audio_file.name} -> {new_name}")
    
    return new_path


def parse_timing_points(osu_content):
    timing_section_match = re.search(r'\[TimingPoints\]\s*\n(.*?)(?=\[|\Z)', osu_content, re.DOTALL)
    
    if not timing_section_match:
        print("⚠️  [TimingPoints] section not found, using default BPM: 120")
        return 120.0, []
    
    timing_lines = timing_section_match.group(1).strip().split('\n')
    timing_points = []
    
    for line in timing_lines:
        line = line.strip()
        if not line or line.startswith('//'):
            continue
        
        parts = line.split(',')
        if len(parts) >= 2:
            try:
                offset = float(parts[0])
                beat_length = float(parts[1])
                
                if beat_length > 0:
                    bpm = 60000.0 / beat_length
                    timing_points.append({
                        'offset': offset,
                        'beatLength': beat_length,
                        'bpm': bpm
                    })
            except ValueError:
                continue
    
    if timing_points:
        bpm = timing_points[0]['bpm']
        print(f"✅ Detected BPM: {bpm:.2f}")
        return bpm, timing_points
    else:
        print("⚠️  Could not parse timing points, using default BPM: 120")
        return 120.0, []


def assign_color_types(notes, num_lanes=4, min_notes=MIN_NOTES_PER_COLOR, max_notes=MAX_NOTES_PER_COLOR, swap_chance=COLOR_SWAP_CHANCE):
    if not notes:
        return notes
    
    target_blue_percentage = BLUE_NOTE_PERCENTAGE_4K if num_lanes == 4 else BLUE_NOTE_PERCENTAGE_6K
    target_blue_count = int(len(notes) * target_blue_percentage)
    
    print(f"🎨 Assigning color types... (Random, min {min_notes}, max {max_notes} notes/color, swap chance: {swap_chance*100:.0f}%)")
    print(f"   🎯 Target: {target_blue_percentage*100:.1f}% blue notes ({target_blue_count}/{len(notes)})")
    
    notes.sort(key=lambda n: n["time"])
    
    time_groups = {}
    for note in notes:
        time_key = round(note["time"], 3)
        if time_key not in time_groups:
            time_groups[time_key] = []
        time_groups[time_key].append(note)
    
    current_color = 0
    notes_since_last_swap = 0
    color_swaps = 0
    blue_count = 0
    
    for i, note in enumerate(notes):
        notes_since_last_swap += 1
        
        should_swap = False
        dynamic_swap_chance = swap_chance
        
        if notes_since_last_swap < min_notes:
            should_swap = False
        elif notes_since_last_swap >= max_notes:
            should_swap = True
        else:
            if current_color == 0:
                remaining_notes = len(notes) - i - 1
                remaining_blue_target = target_blue_count - blue_count
                
                if blue_count >= target_blue_count or remaining_blue_target <= 0:
                    dynamic_swap_chance = swap_chance * 0.1
                elif remaining_notes > 0:
                    required_blue_ratio = remaining_blue_target / remaining_notes
                    dynamic_swap_chance = min(swap_chance, required_blue_ratio * 2.0)
            
            should_swap = random.random() < dynamic_swap_chance
        
        if should_swap:
            current_color = 1 - current_color
            notes_since_last_swap = 0
            color_swaps += 1
        
        note["type"] = current_color
        
        if current_color == 1:
            blue_count += 1
    
    print(f"   🎲 {color_swaps} color swaps made (random, min {min_notes}, max {max_notes})")
    
    chord_fixes = 0
    for time_key in sorted(time_groups.keys()):
        notes_at_time = time_groups[time_key]
        
        if len(notes_at_time) > 1:
            first_color = notes_at_time[0]["type"]
            
            for note in notes_at_time[1:]:
                if note["type"] != first_color:
                    note["type"] = first_color
                    chord_fixes += 1
    
    if chord_fixes > 0:
        print(f"   🔧 {chord_fixes} chord color fixes applied")
    
    pink_count = sum(1 for n in notes if n["type"] == 0)
    blue_count = sum(1 for n in notes if n["type"] == 1)
    print(f"   📊 Pink notes: {pink_count}, Blue notes: {blue_count}")
    
    return notes


def sanitize_notes(notes, bpm, num_lanes=4):
    if not notes:
        return []
    
    notes.sort(key=lambda n: n["time"])
    
    print(f"🧹 Running sanitizer... ({len(notes)} raw notes)")
    
    beat_to_seconds = 60.0 / bpm
    min_gap_seconds = 0.1
    min_gap_beats = min_gap_seconds / beat_to_seconds
    
    cleaned_notes = []
    max_lane = num_lanes - 1
    last_note_time_per_lane = {i: -1000.0 for i in range(max_lane + 1)}
    last_note_end_time_per_lane = {i: -1000.0 for i in range(max_lane + 1)}
    
    time_groups = {}
    for note in notes:
        time_key = round(note["time"], 3)
        if time_key not in time_groups:
            time_groups[time_key] = []
        time_groups[time_key].append(note)
    
    for time_key in sorted(time_groups.keys()):
        notes_at_time = time_groups[time_key]
        
        if len(notes_at_time) > 2:
            import random
            notes_at_time = random.sample(notes_at_time, 2)
            print(f"   ⚠️  At {time_key:.3f} beat, {len(time_groups[time_key])} notes found, reduced to 2")
        
        for note in notes_at_time:
            lane = note["lane"]
            note_time = note["time"]
            note_length = note.get("length", 0.0)
            note_end_time = note_time + note_length
            
            if note_time < last_note_end_time_per_lane[lane]:
                print(f"   ❌ At beat {note_time:.3f} Lane {lane}: Overlaps with hold note, removed")
                continue
            
            time_since_last = note_time - last_note_time_per_lane[lane]
            if time_since_last < min_gap_beats and time_since_last > 0:
                print(f"   ❌ At beat {note_time:.3f} Lane {lane}: Too close ({time_since_last*beat_to_seconds:.3f}s), removed")
                continue
            
            cleaned_notes.append(note)
            
            last_note_time_per_lane[lane] = note_time
            last_note_end_time_per_lane[lane] = note_end_time
    
    cleaned_notes.sort(key=lambda n: n["time"])
    
    removed_count = len(notes) - len(cleaned_notes)
    print(f"✅ Sanitizer complete: {removed_count} notes removed, {len(cleaned_notes)} notes kept")
    
    return cleaned_notes


def parse_hit_objects(osu_content, bpm, num_lanes=4):
    hit_objects_match = re.search(r'\[HitObjects\]\s*\n(.*?)(?=\[|\Z)', osu_content, re.DOTALL)
    
    if not hit_objects_match:
        print("⚠️  [HitObjects] section not found!")
        return []
    
    hit_object_lines = hit_objects_match.group(1).strip().split('\n')
    notes = []
    
    ms_to_beat = bpm / 60000.0
    
    for line in hit_object_lines:
        line = line.strip()
        if not line or line.startswith('//'):
            continue
        
        parts = line.split(',')
        if len(parts) < 4:
            continue
        
        try:
            x = int(parts[0])
            y = int(parts[1])
            time_ms = int(parts[2])
            note_type = int(parts[3])
            
            lane = math.floor(x * num_lanes / OSU_MANIA_WIDTH)
            lane = max(0, min(lane, num_lanes - 1))
            
            time_beat = time_ms * ms_to_beat
            
            is_hold_note = (note_type & 128) != 0
            
            note_length = 0.0
            
            if is_hold_note:
                if len(parts) >= 6:
                    object_params = parts[5].split(':')
                    if len(object_params) >= 1:
                        try:
                            end_time_ms = int(object_params[0])
                            length_ms = end_time_ms - time_ms
                            note_length = length_ms * ms_to_beat
                            note_length = max(0.0, note_length)
                        except ValueError:
                            note_length = 0.0
            
            note = {
                "time": round(time_beat, 3),
                "lane": lane,
                "length": round(note_length, 2),
                "speed": 1.0,
                "type": 0
            }
            
            notes.append(note)
            
        except (ValueError, IndexError) as e:
            print(f"⚠️  Hit object parse error: {line[:50]}... ({e})")
            continue
    
    notes.sort(key=lambda n: n["time"])
    
    print(f"✅ Parsed {len(notes)} notes")
    
    short_notes = sum(1 for n in notes if n["length"] == 0.0)
    hold_notes = sum(1 for n in notes if n["length"] > 0.0)
    print(f"   📊 Short notes: {short_notes}, Hold notes: {hold_notes}")
    
    return notes


def parse_osu_file(osu_path, num_lanes=4):
    print(f"📄 Parsing {osu_path.name}...")
    
    with open(osu_path, 'r', encoding='utf-8') as f:
        osu_content = f.read()
    
    song_name = osu_path.stem
    metadata_match = re.search(r'\[Metadata\]\s*\n(.*?)(?=\[|\Z)', osu_content, re.DOTALL)
    if metadata_match:
        metadata_lines = metadata_match.group(1).strip().split('\n')
        for line in metadata_lines:
            if line.startswith('Title:'):
                song_name = line.split(':', 1)[1].strip()
                break
            elif line.startswith('TitleUnicode:'):
                song_name = line.split(':', 1)[1].strip()
                break
    
    bpm, timing_points = parse_timing_points(osu_content)
    
    notes = parse_hit_objects(osu_content, bpm, num_lanes)
    
    notes = sanitize_notes(notes, bpm, num_lanes)
    
    notes = assign_color_types(notes, num_lanes, MIN_NOTES_PER_COLOR, MAX_NOTES_PER_COLOR, COLOR_SWAP_CHANCE)
    
    base_speed = DEFAULT_BASE_SPEED_4K if num_lanes == 4 else DEFAULT_BASE_SPEED_6K
    
    chart_data = {
        "songName": song_name,
        "bpm": round(bpm, 2),
        "baseSpeed": base_speed,
        "notes": notes
    }
    
    return chart_data


def convert_osz_to_unity(osz_path, output_base_folder):
    print()
    print("=" * 60)
    print(f"🔄 Converting: {osz_path.name}")
    print("=" * 60)
    
    temp_extract = Path(output_base_folder) / "_temp_extract"
    
    try:
        extract_path = extract_osz(osz_path, temp_extract)
        
        audio_path = find_and_rename_audio(extract_path)
        
        osu_files = list(extract_path.glob("*.osu"))
        
        if not osu_files:
            print("❌ .osu file not found!")
            return None
        
        output_folder = Path(output_base_folder) / osz_path.stem
        output_folder.mkdir(parents=True, exist_ok=True)
        
        if audio_path and audio_path.exists():
            shutil.copy2(audio_path, output_folder / audio_path.name)
            print(f"✅ Audio file copied: {output_folder / audio_path.name}")
        
        for osu_file in osu_files:
            for num_lanes in [4, 6]:
                chart_data = parse_osu_file(osu_file, num_lanes)
                
                json_name = f"Chart_{num_lanes}K.json"
                json_path = output_folder / json_name
                
                with open(json_path, 'w', encoding='utf-8') as f:
                    json.dump(chart_data, f, indent=2, ensure_ascii=False)
                
                print(f"✅ {json_name} created: {len(chart_data['notes'])} cleaned notes")
        
        shutil.rmtree(temp_extract, ignore_errors=True)
        
        print(f"✅ Conversion complete: {output_folder}")
        return output_folder
        
    except Exception as e:
        print(f"❌ ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        shutil.rmtree(temp_extract, ignore_errors=True)
        return None


def main():
    print("=" * 60)
    print("🎮 Osu! (.osz) to Unity Rhythm Game JSON Converter")
    print("🧹 Sanitizer Algorithm Active")
    print("=" * 60)
    print()
    print("📋 Sanitizer Rules:")
    print("   1. ✅ Rule 1 (Physics): No new note in the same lane while a hold note is active")
    print("   2. ✅ Rule 2 (Density Cap): Max 2 notes simultaneously")
    print("   3. ✅ Rule 3 (Human Limit): Min 0.1s gap (anti-spam)")
    print()
    
    script_dir = Path(__file__).parent.absolute()
    input_folder = script_dir / INPUT_FOLDER
    output_folder = script_dir / OUTPUT_FOLDER
    
    output_folder.mkdir(exist_ok=True)
    
    osz_files = find_osz_files(input_folder)
    
    if not osz_files:
        print(f"❌ No .osz or .zip files found in {INPUT_FOLDER} folder!")
        print(f"   Please place .osz or .zip files in the input folder.")
        print(f"   Folder path: {input_folder}")
        return
    
    print(f"📂 {len(osz_files)} files found (.osz or .zip)")
    print()
    
    converted_count = 0
    for osz_file in osz_files:
        result = convert_osz_to_unity(osz_file, output_folder)
        if result:
            converted_count += 1
    
    print()
    print("=" * 60)
    print(f"✅ Process complete!")
    print(f"   📁 {converted_count}/{len(osz_files)} files successfully converted")
    print(f"   📂 Output folder: {output_folder}")
    print("=" * 60)
    print()
    print("💡 Tip: You can copy the generated folders to Unity's Resources/Charts folder.")


if __name__ == "__main__":
    main()
